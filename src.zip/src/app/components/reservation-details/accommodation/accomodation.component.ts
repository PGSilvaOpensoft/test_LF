import {Component} from '@angular/core';

@Component({
  selector: 'sc-accommodation',
  templateUrl: './accomodation.component.html',
  styleUrls: ['./accommodation.component.scss'],
})
export class AccommodationComponent {}
