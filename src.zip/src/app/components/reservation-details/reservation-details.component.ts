import {Component} from '@angular/core';

@Component({
  selector: 'sc-reservation-details',
  templateUrl: './reservation-details.component.html',
  styleUrls: ['./reservation-details.component.scss'],
})
export class reservationDetailsComponent {
  constructor() {}
}
