import {Component} from '@angular/core';

@Component({
  selector: 'sc-guests',
  templateUrl: './guests.component.html',
  styleUrls: ['./guests.component.scss'],
})
export class GuestsComponent {
  constructor() {}
}
