## README Links in New Tabs

Since the `README` is to be placed inside an iframe, if any `README` links are to be forcefully opened in new tabs, they should be encased in `HTML` tags, with `target="_blank"`.

Example:
`<a href="https://www.examples.com" target="_blank">Example Link Text</a>`
